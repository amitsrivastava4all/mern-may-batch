export const cartReducer = (
  state = { pizzas: [], orders: [], payments: [] },
  action
) => {
  console.log("I am in reducer after dispatch....", action);
  if (action.type === "BASKET_ADD") {
    const pizzaArray = [...state.pizzas]; // Pizza clone
    pizzaArray.push(action.payload);
    return { pizzas: pizzaArray }; // new state
  }
  return state; // old state
};
