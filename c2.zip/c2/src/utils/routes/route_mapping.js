import { Route, Routes, Switch } from "react-router-dom";
import { Desserts } from "../../components/Desserts";
import { Drinks } from "../../components/Drinks";
import { Pizzas } from "../../components/Pizzas";
import { Constants } from "../constants";
import { Home } from "../../components/Home";
import { Deals } from "../../components/Deals";
import { Offers } from "../../components/Offers";
import { Options } from "../../components/Options";
import { ErrorPage_404 } from "../../components/404";

export const routeMapping = () => {
  const { ROUTES } = Constants;
  // Path Parameter e.g songs/english/2022
  // Query String Parameter ?price=9000&brand=nike
  const DESSERT_ROUTE_WITHPARAMS = `${ROUTES.DESSERTS}/:discount/:date`;
  return (
    // <Switch>
    <Routes>
      {/* <Route exact path={ROUTES.HOME} component={Home} /> */}
      <Route  path={ROUTES.HOME} element={<Home/>} />
      <Route path={ROUTES.PIZZAS} element={<Pizzas/>} />
      <Route path={DESSERT_ROUTE_WITHPARAMS} element={<Desserts/>} />
      <Route path={ROUTES.DRINKS} element={<Drinks/>} />
      <Route path= "options" >
      <Route  index={true} element={<Options/>} />
      <Route  path="deals" element={<Deals/>} />
        <Route  path="offers" element={<Offers/>} />
        </Route>
      {/* <Switch>
        <Route path="/deals" component={Deals} />
        <Route path="/offers" component={Offers} />
      </Switch> */}
      {/* 404 */}
      <Route path="*" element={<ErrorPage_404/>} />
      {/* <Route
        render={() => {
          return <h1>OOPS U Type Some Wrong URL </h1>;
        }}
      /> */}
      </Routes>
   // {/* </Switch> */}
  );
};
