import axios from "axios";
axios.defaults.baseURL = process.env.REACT_APP_BASEURL;

export const getPizza = () => {
  const URL = "https://gist.githubusercontent.com/kshirsagarps/36fade16fa39202715656ef487aaf7b0/raw/2b682e589ef283f06be42d2799dfa54f57794a6e/Pizza.json";
  //const response = axios.get(URL);
  const response = axios({
    // baseURL: process.env.REACT_APP_BASEURL,
    method: "GET",
    url: URL,
  });
  // axios.post(URL, {userid:'amit'})
  return response;
};

export const getPizza2 = () => {
  const axiosObject = axios.create({
    baseURL: "https://abcd.com",
    timeout: 3000,
  });
  const response = axiosObject.get("/Pizza.json");
  return response;
};
