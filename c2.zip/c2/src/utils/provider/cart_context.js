import React from "react";
export const CartContext = React.createContext({
  cartValue: 0,
  updateCart: function () {},
});
