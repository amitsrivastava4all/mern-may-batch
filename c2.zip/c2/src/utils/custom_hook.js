import {useEffect, useState} from 'react';
export const useApi= (url)=>{
    const [data, setData] = useState(null); // Predefine Hook (Help to create My Custom Hook)
    useEffect(()=>{
        const promise = fetch(url);
        promise.then(response=>{
            response.json().then(mydata=>{
                //console.log('Cake Data is ', mydata)
                setData(mydata);
            })
        }).catch(err=>{
            setData(err);
        }).catch(err=>{
            setData(err);
        })
    }, [url]);
   return [data];
}