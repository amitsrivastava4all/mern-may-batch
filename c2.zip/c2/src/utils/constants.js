export const Constants = {
  ROUTES: {
    HOME: "/",
    PIZZAS: "/pizzas",
    DESSERTS: "/desserts",
    DRINKS: "/drinks",
    OPTIONS: "/options",
  },
};
