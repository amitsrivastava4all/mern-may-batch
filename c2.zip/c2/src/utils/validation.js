import * as yup from 'yup';
export function validateRegForm(userInfo){


let form = yup.object().shape({
    name: yup.string().required().min(2).max(10).uppercase(),
    phone: yup.string().required(),
    email:yup.string().required().email()
   
  });
  form.validate(userInfo, { abortEarly: false}).catch(err=>{
    console.log('Error is ',err?.inner);

  })

}