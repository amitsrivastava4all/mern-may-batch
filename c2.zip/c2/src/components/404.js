export const ErrorPage_404 = ()=>{
    return (<h1>Error Page 404</h1>)
}