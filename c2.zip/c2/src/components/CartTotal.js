import { CartContext } from "../utils/provider/cart_context";
import React, { useContext, useState } from "react";
export const CartTotal = () => {
  const cartContext = useContext(CartContext);
  const [cartTotal, setTotal] = useState(0);
  const myCartFn = () => {
    setTotal(cartContext.cartValue);
    console.log("MyCart FN CALL ");
  };
  cartContext.updateCart = myCartFn;
  return (
    <p>
      Cart Total
      <CartContext.Consumer>
        {(ctx) => {
          return <span>{ctx.cartValue}</span>;
        }}
      </CartContext.Consumer>
    </p>
  );
};
