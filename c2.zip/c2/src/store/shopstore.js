import { createStore } from "redux";
import { cartReducer } from "../reducers/reducer";
import { configureStore } from "@reduxjs/toolkit";
import cartSlice from "../reducers/cart_slice";
//const store = createStore(cartReducer);
// Redux ToolKit
const store = configureStore({
  reducer: { cartSlice },
});

store.subscribe(() => {
  console.log("State Update .... ", store.getState());
});
export default store;
