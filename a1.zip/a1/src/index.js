import App from "./App";
import ReactDOM from "react-dom";
ReactDOM.render(<App />, document.querySelector("#root"));
// <App/> internally calling a Component , Component it is a function. App()
