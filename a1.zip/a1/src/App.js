// Root Component , Calling in index.js (JSX Style)
function App() {
  return <h1>Hello React JS, Created by FaceBook</h1>;
}
export default App;
