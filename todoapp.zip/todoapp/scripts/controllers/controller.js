// DOM + Event
import { taskOperations } from "../services/service.js";
import { CONSTANTS } from "../utils/constants.js";
window.addEventListener("load", init);
const { SIZE, HAND, EDIT, FONTAWESOMEBASE, TRASH, CIRCLE, MARGIN_RIGHT } =
  CONSTANTS.CLASSES;
const { COLOR, URL } = CONSTANTS.KEYS;
function init() {
  bindEvents();
  totalSummary();
}
function bindEvents() {
  document.querySelector("#add").addEventListener("click", addTask);
}
function addTask() {
  let fields = ["id", "name", "desc", "priority", "date", "url", "color"];
  const fieldData = {}; // Object Literal
  for (let field of fields) {
    fieldData[field] = document.querySelector(`#${field}`).value;
  }
  const taskObject = taskOperations.add(fieldData);
  console.log("Added ", taskObject);
  printTask(taskObject);
  totalSummary();
}
function printTask(taskObject) {
  const tbody = document.querySelector("#tasks");
  const tr = tbody.insertRow();
  let index = 0;
  for (let key in taskObject) {
    if (key == URL) {
      tr.insertCell(index).appendChild(createImage(taskObject[key]));
      index++;
      continue; // skip
    }
    if (key == COLOR) {
      tr.insertCell(index).appendChild(createColor(taskObject[key]));
      index++;
      continue;
    }
    tr.insertCell(index).innerText = taskObject[key];
    index++;
  }
  const td = tr.insertCell(index);
  td.appendChild(createIcon(`${TRASH} ${MARGIN_RIGHT}`));
  td.appendChild(createIcon(EDIT));
}

function totalSummary() {
  document.querySelector("#total").innerText = taskOperations.getTotalTasks();
}

function createIcon(cssClass) {
  const icon = document.createElement("i");
  icon.className = `${HAND} ${FONTAWESOMEBASE} ${cssClass}`;
  // <i class="fa-solid fa-pen"></i> // fa-trash-can
  return icon;
}
function createImage(url) {
  const image = document.createElement("img");
  image.src = url;
  image.className = SIZE;
  return image;
}

function createColor(color) {
  const circle = document.createElement("div");
  circle.className = CIRCLE;
  circle.style.backgroundColor = color;
  return circle;
}
