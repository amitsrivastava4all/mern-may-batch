// CRUD Logic
//import { Task } from "./model.js";
import Task from "../models/task.js";
export const taskOperations = {
  tasks: [],
  getTotalTasks() {
    return this.tasks.length;
  },
  add(fieldData) {
    var taskObject = new Task();
    for (let key in fieldData) {
      taskObject[key] = fieldData[key];
    }
    this.tasks.push(taskObject);
    return taskObject;
  },
  remove() {},
  update() {},
  search() {},
  sort() {},
};
