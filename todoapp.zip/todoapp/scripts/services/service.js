// CRUD Logic
//import { Task } from "./model.js";
import Task from "../models/task.js";
export const taskOperations = {
  tasks: [], // store task objects
  getTotalTasks() {
    return this.tasks.length;
  },
  find(fieldName, fieldValue,type){
    if(type=='N'){
      return this.tasks.filter(task=>task[fieldName] ==fieldValue);
    }
    
    return this.tasks.filter(task=>task[fieldName].includes(fieldValue));
  },
  deleteForEver() {
    this.tasks = this.tasks.filter((task) => !task.isReadyForDelete);
    return this.tasks;
  },
  countUnMark() {
    return this.getTotalTasks() - this.countMark();
  },
  countMark() {
    return this.tasks.filter((task) => task.isReadyForDelete).length;
  },
  toggleMark(id) {
    const taskObject = this.tasks.find((task) => task.id == id);
    if (taskObject) {
      taskObject.isReadyForDelete = !taskObject.isReadyForDelete;
    }
  },
  add(fieldData) {
    var taskObject = new Task();
    for (let key in fieldData) {
      taskObject[key] = fieldData[key];
    }
    this.tasks.push(taskObject);
    return taskObject;
  },
  remove() {},
  update() {},
  search() {},
  sort() {},
};
