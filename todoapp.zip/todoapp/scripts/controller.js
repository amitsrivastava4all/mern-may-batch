// DOM + Event
window.addEventListener("load", bindEvents);
import { taskOperations } from "./service.js";
window.addEventListener("load", bindEvents);
function bindEvents() {
  document.querySelector("#add").addEventListener("click", addTask);
}
function addTask() {
  let fields = ["id", "name", "desc", "priority", "date", "url", "color"];
  const fieldData = {}; // Object Literal
  for (let field of fields) {
    fieldData[field] = document.querySelector(`#${field}`).value;
  }
  taskOperations.add(fieldData);
  console.log(fieldData);
}
