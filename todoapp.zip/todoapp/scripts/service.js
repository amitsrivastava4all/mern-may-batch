// CRUD Logic
//import { Task } from "./model.js";
import Task from "./model.js";
export const taskOperations = {
  add(fieldData) {
    var taskObject = new Task();
  },
  remove() {},
  update() {},
  search() {},
  sort() {},
};
