window.addEventListener('load', bindEvents);
function bindEvents(){
    var button = document.getElementById('bt');
button.addEventListener('click', counter);
}
var count = 0;
function counter(){
    count++;
    console.log('Count is ', count);
    document.getElementById('result').innerText =count;

}