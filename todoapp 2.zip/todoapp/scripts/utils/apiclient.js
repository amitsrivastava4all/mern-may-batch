export function getServerTask(){
    const URL = "https://raw.githubusercontent.com/amitsrivastava4all/task-json/main/tasks.json";
    const promise = fetch(URL);
    return promise;
}