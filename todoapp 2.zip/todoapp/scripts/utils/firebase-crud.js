import {db} from './firebase-config.js';
export const firebaseCRUD = {
    add(task){
        const obj = {};
        for(let key in task){
            obj[key] = task[key];
        }
         //console.log(db.collection);
         const promise = db.collection('tasks').add(obj);
         promise.then(data=>{
             console.log('Record Added', data);
         }).catch(err=>{
             console.log('Error in Add ',err);
         })
        // console.log("FireBase ", firebase.firestore());
     },
     read(){
        db.collection("tasks").get().then((querySnapshot) => {
            querySnapshot.forEach((doc) => {
                console.log(doc.id, doc.data() );
            });
        });
     }

     
    
}