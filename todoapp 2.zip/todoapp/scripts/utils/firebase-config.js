
  
  // import firebase from "firebase/app";
  // import "firebase/firestore";

  const firebaseConfig = {
    apiKey: "AIzaSyAk4d4Q19cP5VJ2Y3ZgVI0CZ_vzeJD6uqk",
    authDomain: "taskcrud-bb954.firebaseapp.com",
    projectId: "taskcrud-bb954",
    storageBucket: "taskcrud-bb954.appspot.com",
    messagingSenderId: "763669479352",
    appId: "1:763669479352:web:2bf976212e07348ec6d94d",
    measurementId: "G-VZH4VS4HL1"
  };

  // Initialize Firebase
  console.log('Firebase object is ', firebase);
  firebase.initializeApp(firebaseConfig);
  
  export const db = firebase.firestore();
  console.log('DB is ', db);
