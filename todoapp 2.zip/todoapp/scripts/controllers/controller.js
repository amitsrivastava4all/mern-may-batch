// DOM + Event
import { taskOperations } from "../services/service.js";
import { CONSTANTS } from "../utils/constants.js";
import { firebaseCRUD } from "../utils/firebase-crud.js";
window.addEventListener("load", init);
const { SIZE, HAND, EDIT, FONTAWESOMEBASE, TRASH, CIRCLE, MARGIN_RIGHT } =
  CONSTANTS.CLASSES;
const { COLOR, URL } = CONSTANTS.KEYS;
function init() {
  bindEvents();
  //totalSummary();
  loadDataFromSerer();
  loadFromFireBase();
}

function loadFromFireBase(){
  firebaseCRUD.read();
}

async function loadDataFromSerer(){
   await taskOperations.loadTaskFromServer();
   printTable(taskOperations.tasks);
   totalSummary();
}
function bindEvents() {
  document.querySelector('#save').addEventListener('click', save);
  document.querySelector('#load').addEventListener('click', load);
  document.querySelector('#update').addEventListener('click', update);
  document.querySelector('#searchtxt').addEventListener('keyup', searchIt);
  document.querySelector("#add").addEventListener("click", addTask);
  document.querySelector("#delete").addEventListener("click", deleteForEver);
  document.querySelector('#searchnow').addEventListener('click', search);
}

function save(){
  if(window.localStorage){
    localStorage.mytaskdata = JSON.stringify(taskOperations.tasks);
    alert("Data Saved...");
  }
  else{
    alert("No LocalStoage U Have Outdated Browser...");
  }
}

function load(){
  if(window.localStorage){
    if(localStorage.mytaskdata){
      const allTask = JSON.parse(localStorage.mytaskdata);
      printTable(allTask);
      totalSummary();
    }
    else{
      alert("U Don't Have any data to load...");
    }
  }
  else{
    alert("No LocalStoage U Have Outdated Browser...");
  }
}

function searchIt(evt){
  console.log(this.value , 'Event is ',evt);
  if(evt.code=='Enter'){
    search();
  }
}
function search(){
  let searchValue = document.querySelector("#searchtxt").value;
  const result = taskOperations.find('name',searchValue);
  if(result.length==0){
    alert("No Record Found");
    return ;
  }
  printTable(result);
  totalSummary(result);
}
function deleteForEver() {
  const tasks = taskOperations.deleteForEver();
  printTable(tasks);
}
function printTable(tasks) {
  document.querySelector("#tasks").innerHTML = "";
  tasks.forEach((task) => printTask(task));
  totalSummary();
}
function addTask() {
  let fields = ["id", "name", "desc", "priority", "date", "url", "color"];
  const fieldData = {}; // Object Literal
  for (let field of fields) {
    fieldData[field] = document.querySelector(`#${field}`).value;
  }
  const taskObject = taskOperations.add(fieldData);
  console.log("Added ", taskObject);
  printTask(taskObject);
  totalSummary();
  // Add the Record to the Firebase Cloud
  firebaseCRUD.add(taskObject);
}
function printTask(taskObject) {
  const tbody = document.querySelector("#tasks");
  const tr = tbody.insertRow();
  let index = 0;
  for (let key in taskObject) {
    if (key == URL) {
      tr.insertCell(index).appendChild(createImage(taskObject[key]));
      index++;
      continue; // skip
    } else if (key == COLOR) {
      tr.insertCell(index).appendChild(createColor(taskObject[key]));
      index++;
      continue;
    } else if (key == "isReadyForDelete") {
      continue;
    }

    tr.insertCell(index).innerText = taskObject[key];
    index++;
  }
  const td = tr.insertCell(index);
  td.appendChild(
    createIcon(`${TRASH} ${MARGIN_RIGHT}`, markForDelete, taskObject["id"])
  );
  td.appendChild(createIcon(EDIT, edit, taskObject["id"]));
}

function totalSummary(result ) {
  if(!result){
  document.querySelector("#total").innerText = taskOperations.getTotalTasks();
  
  }
  else{
    document.querySelector("#total").innerText = result.length;
  }
  document.querySelector("#mark").innerText = taskOperations.countMark();
  document.querySelector("#unmark").innerText = taskOperations.countUnMark();
  disableDelete();
}

function update(){
  for(let key in task){
    if(key == 'isReadyForDelete'){
      continue;
    }
    task[key] =  document.querySelector(`#${key}`).value ;
  }
  printTable(taskOperations.tasks);
  totalSummary();
}
let task ;
function edit() {
  const icon = this;
  const id = icon.getAttribute("task-id");
  const records = taskOperations.find('id',id,'N');
 task = records?records[0]:{};
  for(let key in task){
    if(key == 'isReadyForDelete'){
      continue;
    }
    document.querySelector(`#${key}`).value = task[key];
  }
  console.log("EDIT Icon is ", icon);
}
function markForDelete() {
  const icon = this;
  const id = icon.getAttribute("task-id");
  taskOperations.toggleMark(id);
  console.log("Icon is ", icon);
  const tr = icon.parentNode.parentNode;
  // tr.className = "alert-danger";
  tr.classList.toggle("alert-danger");
  totalSummary();
}

const disableDelete = () =>
  (document.querySelector("#delete").disabled =
    taskOperations.countMark() == 0);

function createIcon(cssClass, fn, taskId) {
  const icon = document.createElement("i");
  icon.className = `${HAND} ${FONTAWESOMEBASE} ${cssClass}`;
  icon.addEventListener("click", fn);
  // Custom Attribute
  icon.setAttribute("task-id", taskId);
  // <i class="fa-solid fa-pen"></i> // fa-trash-can
  return icon;
}
function createImage(url) {
  const image = document.createElement("img");
  image.src = url;
  image.className = SIZE;
  return image;
}

function createColor(color) {
  const circle = document.createElement("div");
  circle.className = 'colorcircle';
  circle.style.backgroundColor = color;
  return circle;
}
