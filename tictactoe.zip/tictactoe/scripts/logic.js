window.addEventListener("load", bindEvents);
let buttons;
function bindEvents() {
  //document.getElementsByTagName('button');
  buttons = document.querySelectorAll("button");
  buttons.forEach((button) => button.addEventListener("click", printXorZero));
}
// button is the calling point of printXorZero
// button is an object (DOM )
// object is calling printXorZero
// when object is calling a function , so object reference is pass to
// the function , a function can use the reference by the special keyword
// called this.
var flag = true;
var clickCount = 0;
var isGameStop = false;
function printXorZero() {
  // console.log("Print X or zero ", this);
  let currentButton = this;
  if (!isGameStop && currentButton.innerText.length == 0) {
    clickCount++;
    currentButton.innerText = flag ? "X" : "0";
    if (clickCount >= 5 && isGameOver()) {
      document.querySelector("#msg").innerText = "Game Over";
    }

    flag = !flag;
  }
}

const isNotBlank = (button) => button.innerText.length > 0;

const isSameRow = (one, two, three) => {
  if (isNotBlank(one) && isNotBlank(two) && isNotBlank(three)) {
    if (one.innerText === two.innerText && one.innerText == three.innerText) {
      return true;
    }
  }
  return false;
};

function isGameOver() {
  isGameStop =
    isSameRow(buttons[0], buttons[1], buttons[2]) ||
    isSameRow(buttons[3], buttons[4], buttons[5]) ||
    isSameRow(buttons[6], buttons[7], buttons[8]);
  return isGameStop;
}
